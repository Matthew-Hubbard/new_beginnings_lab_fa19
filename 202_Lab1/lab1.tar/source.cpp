#include <iostream>
#include "source.h"

using namespace std;

const int NAME = 20;

int main() 
{
    //cout << "Default constructor: \n";
    orc orc_obj;
    orc_obj.display();

    char name[NAME];
    cout << "Enter name: ";
    cin.get(name, NAME, '\n');
    cin.ignore(100, '\n');

    //cout << "Constructor with args:\n";
    orc orc_obj2(100, name);
    orc_obj2.display();

    orc_obj.attack();
    orc_obj2.take_dmg(20);

    orc_obj2.smash();
    orc_obj.take_dmg(100);

    orc_obj.display();
    orc_obj2.display();

    return 0;
} 

//--MONSTER CLASS--
monster::monster() : health(50), name(NULL) //initialization list
{ prompt_name();}

monster::~monster() //destructor
{
  if(name)
    delete [] name;
}

monster::monster(int hp) : health(hp), name(NULL) //initialization list
{
    prompt_name();
}

monster::monster(int hp, char * name): health(hp), name(NULL)
{
    //deep copy
    this->name = new char [strlen(name) + 1];
    strcpy(this->name, name);
}

monster::monster(const monster & copy_from) : health(copy_from.health)
{
  name = new char [strlen(copy_from.name) + 1];
  strcpy(name, copy_from.name);
}

void monster::prompt_name()
{
    char temp[NAME];
    cout << "Enter name: ";
    cin.get(temp, NAME, '\n');
    cin.ignore(100, '\n');
    name = new char [strlen(temp) + 1];
    strcpy(name, temp);
}

void monster::display() const { 
    cout << "Name: " << name << endl;
    cout << "Health: " << health << endl;}

void monster::take_dmg(int dmg) {
    health -= dmg;
    if(health <= 0)
        cout << name << " has died!\n";}

void monster::attack()
{
    cout << name << " attacks with basic attack!\n";
}

//--ORC CLASS--
orc::orc(){}

orc::orc(int hp) : monster(hp) {}
orc::orc(int hp, char * name) : monster(hp, name) //call base class constructor with args
{}

void orc::display() const { 
    monster::display();
    cout << "Race: Orc" << endl;}

void orc::smash() {
    cout << name << " smashes! **ORC SMASH! ORC SMASH!**\n";}
/*
//--GOBLIN CLASS--
goblin::goblin(){}

goblin::goblin(int hp) : monster(hp) {}
*/
