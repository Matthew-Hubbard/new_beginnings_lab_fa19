#include <cstring>

using namespace std;

class monster
{
    public: //can access from any scope 
        monster(); //default constructor
        ~monster(); //destructor
        monster(int hp); //constructor with arg 
        monster(int hp, char * name); //constructor with args
        monster(const monster &); //copy constructor

        //public member functions
        void display() const;
        void take_dmg(int dmg);
        void attack();
        void prompt_name();
    protected: //other classes in hierachy can access
        //data members
        int health;
        char * name;
    private: //only this class can access
        //int health;
};

class orc: public monster //derivation list
{
    public:
        orc(); //default constructor
        orc(int hp);
        orc(int hp, char * name);
        void smash();
        void display() const;
    protected:
    private:
};
/*
class goblin: public monster
{
    public:
        goblin();
        goblin(int hp);
    protected:
    private:
};
*/

